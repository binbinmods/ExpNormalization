# 1.0.3

Fixed Dream Combat exp

# 1.0.2

Fixed Act 2 and 3 starter enemies giving the wrong experience

# 1.0.1

Swapped from using the CombatData CombatTier to NodeData's NodeCombatTier

# 1.0.0

Initial release.
